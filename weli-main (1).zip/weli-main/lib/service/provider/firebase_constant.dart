class FireConstant {
  static String PROFILES = "profiles";
  static String CARDS = "cards";
  static String SALONS = "salons";
  static String USERS = "user";
  static String CARD_REACTIONS = "cardReactions";
}
