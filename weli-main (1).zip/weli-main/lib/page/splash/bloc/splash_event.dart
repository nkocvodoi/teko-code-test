part of 'splash_bloc.dart';

@immutable
abstract class SplashEvent {}

class InitStart extends SplashEvent {}
