package com.florentalbero.weli1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
